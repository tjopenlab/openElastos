#include <stdio.h>
#include <stdlib.h>
/* $Id $ */

void proc_head (char *mes)
{
    fprintf(stderr,"\n\
**************************************************************\n\
\n\
     European digital cellular telecommunications system\n\
           4750 ... 12200 bits/s speech codec for\n\
         Adaptive Multi-Rate speech traffic channels\n\
\n\
     Bit-Exact C Simulation Code - %s\n\
\n\
     Version 7.3.0\n\
     December 13, 1999\n\
**************************************************************\n\n",
            mes);

}
