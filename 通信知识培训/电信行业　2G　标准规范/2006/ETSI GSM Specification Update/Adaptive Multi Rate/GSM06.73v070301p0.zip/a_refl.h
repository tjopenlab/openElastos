/*
********************************************************************************
*
*      GSM AMR speech codec   Version 7.3.0   December 13, 1999
*
********************************************************************************
*
*      File             : a_refl.h
*      Purpose          : Convert from direct form coefficients to 
*                         reflection coefficients
*
********************************************************************************
*/
#ifndef a_refl_h
#define a_refl_h "$Id $"

/*
********************************************************************************
*                         INCLUDE FILES
********************************************************************************
*/
#include "typedef.h"

/*
********************************************************************************
*                         DEFINITION OF DATA TYPES
********************************************************************************
*/

/*
********************************************************************************
*                         DECLARATION OF PROTOTYPES
********************************************************************************
*/

/*************************************************************************
 *
 *   FUNCTION:  A_Refl()
 *
 *   PURPOSE: Convert from direct form coefficients to reflection coefficients
 *
 *   DESCRIPTION:
 *       Directform coeffs in Q12 are converted to 
 *       reflection coefficients Q15 
 *
 *************************************************************************/
void A_Refl(
   Word16 a[],	      /* i   : Directform coefficients */
   Word16 refl[]      /* o   : Reflection coefficients */
);

#endif
