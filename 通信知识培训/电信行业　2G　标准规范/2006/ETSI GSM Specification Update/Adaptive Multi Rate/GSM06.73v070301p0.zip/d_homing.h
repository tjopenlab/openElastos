/*
********************************************************************************
*
*      GSM AMR speech codec   Version 7.3.0   December 13, 1999
*
********************************************************************************
*      File             : d_homing.h
*      Purpose          : Declarations of decoder homing function prototypes.
*
********************************************************************************
*/

#ifndef d_homing_h
#define d_homing_h "$Id $"

/*
*****************************************************************************
*                         INCLUDE FILES
*****************************************************************************
*/

#include "typedef.h"
#include "mode.h"

/*
********************************************************************************
*                         DECLARATION OF PROTOTYPES
********************************************************************************
*/

Word16 decoder_homing_frame_test (Word16 input_frame[], enum Mode mode);
Word16 decoder_homing_frame_test_first (Word16 input_frame[], enum Mode mode);

#endif
