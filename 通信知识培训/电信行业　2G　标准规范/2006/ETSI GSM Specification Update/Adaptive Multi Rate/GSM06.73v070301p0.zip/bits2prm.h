/*
*****************************************************************************
*
*      GSM AMR speech codec   Version 7.3.0   December 13, 1999
*
*****************************************************************************
*
*      File             : bits2prm.h
*      Purpose          : Retrieves the vector of encoder parameters from 
*                       : the received serial bits in a frame.
*
*****************************************************************************
*/
#ifndef bits2prm_h
#define bits2prm_h "$Id $"
 
/*
*****************************************************************************
*                         INCLUDE FILES
*****************************************************************************
*/
#include "typedef.h"
#include "mode.h"
/*
*****************************************************************************
*                         DEFINITION OF DATA TYPES
*****************************************************************************
*/
 
/*
*****************************************************************************
*                         DECLARATION OF PROTOTYPES
*****************************************************************************
*/
/*
**************************************************************************
*
*  Function    : Bits2prm
*  Purpose     : Retrieves the vector of encoder parameters from 
*                the received serial bits in a frame.
*  Returns     : void
*
**************************************************************************
*/
void Bits2prm (
    enum Mode mode,
    Word16 bits[],   /* input : serial bits, (244 + bfi)               */
    Word16 prm[]     /* output: analysis parameters, (57+1 parameters) */
); 
 
#endif
