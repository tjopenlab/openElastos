/*
*****************************************************************************
*
*      GSM AMR speech codec   Version 7.3.0   December 13, 1999
*
*****************************************************************************
*
*      File             : strfunc.h
*      Purpose          : string <-> mode and string <-> traffic channel
*                         conversion functions
*
*****************************************************************************
*/

#ifndef strfunc_h
#define strfunc_h "$Id $"
 
/*
*****************************************************************************
*                         INCLUDE FILES
*****************************************************************************
*/
#include "mode.h"
#include "frame.h"

/*
*****************************************************************************
*                         DECLARATION OF PROTOTYPES
*****************************************************************************
*/

int str2mode(const char* str, enum Mode    *mode);
int mode2str(enum Mode    mode, char** str);
int rxframe2str(enum RXFrameType ft, char** str);
int txframe2str(enum TXFrameType ft, char** str);

#endif
