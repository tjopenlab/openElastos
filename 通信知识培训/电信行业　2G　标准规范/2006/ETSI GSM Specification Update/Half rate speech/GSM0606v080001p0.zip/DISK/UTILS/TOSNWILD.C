/*****************************************************************************
 *
 *   File Name: tosnwild.c
 *   Purpose:   convert PC formatted text files to SUN format
 *
 *   Revision History:
 *
 *  V #  Date           Description
 *  ===  =============  ====================================
 *    0  March 2, 1993  Original
 *    1  Nov. 23, 1993  Comments
 *
 ****************************************************************************/

/*___________________________________________________________________________
 |                                                                           |
 |                              Include Files                                |
 |___________________________________________________________________________|
*/

#include <stdio.h>
#include <stdlib.h>


/*___________________________________________________________________________
 |                                                                           |
 |                              Local Defines                                |
 |___________________________________________________________________________|
*/

#define ADD_RET 0                      /* 1 - add a RET for each LFD you
                                        * find */

/*****************************************************************************
 *
 *   FUNCTION NAME: tosnwild
 *
 *   PURPOSE:
 *     convert text files from PC/DOS format to Sun/UNIX/VAX format.
 *
 *   INPUTS/OUTPUTS:
 *
 *     One or more text filenames to be converted.  The filenames
 *     may use wild cards.  Those same files are modified.
 *
 *     A temporary file is created: junk.tmp
 *     syntax:   topcwld *.c *.h xyz.* ??123.*
 *
 *   IMPLEMENTATION:
 *
 *     Convert a text file from pc format to Sun/UNIX/VAX format.
 *     This involves deleting the ^Z at the end of file and removing the
 *     ^M preceding the ^N at the end of a line.
 *
 *     ^m is (015 RET)
 *     ^n (012 LFD)
 *
 *   KEYWORDS: text format, conversion, portablility
 *
 ****************************************************************************/

main(int argc, char **argv)
{
  int    i,
         charCnt,
         iFile;
  int    this,
         prevThis;
  FILE  *fpin,
        *fpout;


  if (argc < 2) {

    printf("convert text files from PC/DOS format to Sun/UNIX/VAX format\n");
    printf("calling convention\n");
    printf("   tosnwild *.c *.h xyz.* ??123.* etc.\n");
    exit(1);

  }

  printf("files to change \n0. ");

  for (iFile = 1; iFile < argc; iFile++) {

    if (!(iFile % 3))
      printf("\n%d. ", iFile);

    printf("%s ", argv[iFile]);

  }
  printf("\n");

  /* printf("\n\n\nYou have 20 seconds to interrupt\n\n"); sleep(20); */

  printf("\nbeginning renaming\n");

  for (iFile = 1; iFile < argc; iFile++) {

    fpin = (FILE *) fopen(argv[iFile], "r");
    fpout = (FILE *) fopen("junk.tmp", "w");

    printf("opened file: %s\n", argv[iFile]);
    for (charCnt = 0, this = 1; this != EOF && this != 0; charCnt++) {

      this = fgetc(fpin);
      if (this != EOF) {

        /* is this a special character: character cntl-M or ^n?? ^Z */
        /*----------------------------------------------------------*/

        if (this != 015 && this != 012 && this != 032) {
          fputc(this, fpout);
        }
        else {

          /* special pc character */
          if (this == 012 && ADD_RET && prevThis != 015) {
            /* to pc */
            fputc(015, fpout);         /* RET */
            fputc(012, fpout);         /* LFD */
          }
          else if (!ADD_RET && (this == 015 || this == 032)) {
            /* to sun, skip all RET's, ^Z */
          }
          else {                       /* pass a line feed */
            fputc(this, fpout);        /* LFD */
          }
        }
        prevThis = this;
      }
    }

    /* done with this file */
    /*---------------------*/

    fclose(fpin);
    fclose(fpout);

    /* copy new file to old file */
    /*---------------------------*/

    if ((fpout = (FILE *) fopen(argv[iFile], "w")) == NULL)
      printf("could not re-open %s\n", argv[iFile]);

    if ((fpin = (FILE *) fopen("junk.tmp", "r")) == NULL)
      printf("could not re-open %s\n", "junk.tmp");

    printf("rewriting file: %s\n", argv[iFile]);

    for (charCnt = 0, this = 1; this != EOF && this != 0; charCnt++) {
      this = fgetc(fpin);

      if (this != EOF && this != 0) {
        fputc(this, fpout);
      }
    }
    fclose(fpin);
    fclose(fpout);
  }
  return (0);
}
